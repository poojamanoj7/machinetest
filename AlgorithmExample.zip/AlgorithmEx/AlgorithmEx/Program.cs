﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmEx
{
    class Program
    {
        static void Main()
        {
            List<Item> inventory = new List<Item>
        {
            new Item(101, 50, 100, 5, 20),
            new Item(102, 200, 150, 3, 50),
            new Item(103, 80, 120, 4, 30)
        };

            Console.WriteLine("Reordering Plan:");
         
            foreach (var item in inventory)
            {
                int unitsToOrder = item.CalculateReorder();
                if (unitsToOrder > 0)
                {
                    Console.WriteLine($"Item ID: {item.ItemID}, Units to Order: {unitsToOrder}");
                }
            }
            Console.ReadLine();
        }
    }

    class Item
    {
        public int ItemID { get; }
        public int CurrentStock { get; set; }
        public int ForecastedDemand { get; set; }
        public int ReorderCostPerUnit { get; set; }
        public int BatchSize { get; set; }

        public Item(int id, int stock, int demand, int cost, int batch)
        {
            ItemID = id;
            CurrentStock = stock;
            ForecastedDemand = demand;
            ReorderCostPerUnit = cost;
            BatchSize = batch;
        }

        public int CalculateReorder()
        {
            int needed = ForecastedDemand - CurrentStock;
            return needed > 0 ? ((needed / BatchSize) + 1) * BatchSize : 0;
        }
    }
}
