﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace machinetest
{
    class BaseEmployee
    {
        public string Name { get; set; }
        public int ID { get; set; }
        public string Role { get; set; }
        public double BasicPay { get; set; }
        public double Allowances { get; set; }
        public double Deductions { get; set; }

        public BaseEmployee(string name, int id, string role, double basicPay, double allowances, double deductions)
        {
            Name = name;
            ID = id;
            Role = role;
            BasicPay = basicPay;
            Allowances = allowances;
            Deductions = deductions;
        }

        public virtual double CalculateSalary()
        {
            return BasicPay + Allowances - Deductions;
        }

        public virtual void DisplayDetails()
        {
            Console.WriteLine($"ID: {ID}, Name: {Name}, Role: {Role}, Salary: {CalculateSalary():C}");
        }
    }
    class Manager : BaseEmployee
    {
        public double Bonus { get; set; }

        public Manager(string name, int id, double basicPay, double allowances, double deductions, double bonus)
            : base(name, id, "Manager", basicPay, allowances, deductions)
        {
            Bonus = bonus;
        }

        public override double CalculateSalary()
        {
            return base.CalculateSalary() + Bonus;
        }
    }
    class Developer : BaseEmployee
    {
        public Developer(string name, int id, double basicPay, double allowances, double deductions)
            : base(name, id, "Developer", basicPay, allowances, deductions)
        { }
    }
    class Intern : BaseEmployee
    {
        public Intern(string name, int id, double basicPay, double allowances, double deductions)
            : base(name, id, "Intern", basicPay, allowances, deductions)
        { }

        public override double CalculateSalary()
        {
            return base.CalculateSalary() * 0.9; 
        }
    }

  



}
