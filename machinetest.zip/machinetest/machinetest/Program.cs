﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace machinetest
{
    class Program
    {
        static List<BaseEmployee> employees = new List<BaseEmployee>();
        static string filePath = "employees.txt";

        static void Main()
        {
            LoadEmployees(); 

            while (true)
            {
                Console.WriteLine("\nEmployee Payroll System");
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. Display Employees");
                Console.WriteLine("3. Calculate Total Payroll");
                Console.WriteLine("4. Exit");
                Console.Write("Enter choice: ");

                switch (Console.ReadLine())
                {
                    case "1": AddEmployee(); break;
                    case "2": DisplayEmployees(); break;
                    case "3": CalculateTotalPayroll(); break;
                    case "4": SaveEmployees(); return;
                    default: Console.WriteLine("Invalid choice. Try again."); break;
                }
            }
        }

        static void AddEmployee()
        {
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter ID: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Enter Role (Manager/Developer/Intern): ");
            string role = Console.ReadLine().ToLower();

            Console.Write("Enter Basic Pay: ");
            double basicPay = double.Parse(Console.ReadLine());

            Console.Write("Enter Allowances: ");
            double allowances = double.Parse(Console.ReadLine());

            Console.Write("Enter Deductions: ");
            double deductions = double.Parse(Console.ReadLine());

            BaseEmployee emp;
            if (role == "manager")
                emp = new Manager(name, id, basicPay, allowances, deductions, 5000);
            else if (role == "developer")
                emp = new Developer(name, id, basicPay, allowances, deductions);
            else if (role == "intern")
                emp = new Intern(name, id, basicPay, allowances, deductions);
            else
                emp = null;

            if (emp != null)
            {
                employees.Add(emp);
                Console.WriteLine("Employee added successfully!");
            }
            else
            {
                Console.WriteLine("Invalid role. Employee not added.");
            }
        }

        static void DisplayEmployees()
        {
            Console.WriteLine($"Total Employees: {employees.Count}");
            if (employees.Count == 0)
            {
                Console.WriteLine("No employees found.");
                return;
            }

            foreach (var emp in employees)
            {
                Console.WriteLine($"Displaying: {emp.Name} ({emp.Role})");
                emp.DisplayDetails();
            }
        }

        static void CalculateTotalPayroll()
        {
            double totalPayroll = 0;
            foreach (var emp in employees)
            {
                totalPayroll += emp.CalculateSalary();
            }
            Console.WriteLine($"Total Payroll: {totalPayroll:C}");
        }

        static void SaveEmployees()
        {
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                foreach (var emp in employees)
                {
                    sw.WriteLine($"{emp.ID},{emp.Name},{emp.Role},{emp.BasicPay},{emp.Allowances},{emp.Deductions}");
                }
            }

            if (File.Exists(filePath))
            {
                Console.WriteLine("File successfully saved at: " + Path.GetFullPath(filePath));
            }
            else
            {
                Console.WriteLine("Error: File was not created!");
            }
        }

        static void LoadEmployees()
        {
            if (File.Exists(filePath))
            {
                employees.Clear();

                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    var data = line.Split(',');

                    if (data.Length != 6)
                    {
                        continue; 
                    }

                    try
                    {
                        int id = int.Parse(data[0]);
                        string name = data[1];
                        string role = data[2].ToLower();
                        double basicPay = double.Parse(data[3]);
                        double allowances = double.Parse(data[4]);
                        double deductions = double.Parse(data[5]);

                        BaseEmployee emp = null;
                        if (role == "manager")
                            emp = new Manager(name, id, basicPay, allowances, deductions, 5000);
                        else if (role == "developer")
                            emp = new Developer(name, id, basicPay, allowances, deductions);
                        else if (role == "intern")
                            emp = new Intern(name, id, basicPay, allowances, deductions);

                        if (emp != null)
                        {
                            employees.Add(emp); 
                        }
                    }
                    catch
                    {
                        continue; 
                    }
                }
            }
        }


    }
}